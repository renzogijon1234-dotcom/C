# crud-full-stack-refactoring-1.0
Prototipo de CRUD Full Stack refactorizado versión 1.0
![Diagrama de secuencia de de la obtención de estudiantes](/uml/diagrama_de_secuencia_refactoring-1.0.png?raw=true "Diagrama de secuencia de de la obtención de estudiantes")