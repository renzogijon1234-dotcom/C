Project Authors
===============

This project is an educational prototype of a CRUD (Create Read Update and Delete) web application, using HTML, CSS, Javascript and PHP technologies.


## Developers:

* Brenda Andino - full stack - Mar del Plata (Argentina)
* Kevin Taylor - full stack - Mar del Plata (Argentina)
* Lucas de Llelis - full stack - Mar del Plata (Argentina)
* Luis Manterola - full stack - Mar del Plata (Argentina)
* Fernando Genin - full stack - Mar del Plata (Argentina)
* Gabriel "Nico" Ferreira - full stack - Mar del Plata (Argentina)  

## All other contributors and their affiliations:

* Estudiantes de Tecnologías B - Mar del Plata (Argentina)

    * Many intelligent people.


## Special thanks to
As long as it doesn't dirty the chair =] (Mandarina)