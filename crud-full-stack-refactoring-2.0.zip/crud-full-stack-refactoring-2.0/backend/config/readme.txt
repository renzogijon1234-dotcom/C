/*Este es el comando que pueden usar para importar la base de datos 
y la creación de usuario para el proyecto desde la terminal
unicados en el directorio raiz del proyecto*/
mysql -u root -p < backend/config/import_db.sql